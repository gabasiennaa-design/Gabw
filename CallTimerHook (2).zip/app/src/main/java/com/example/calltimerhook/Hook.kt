
package com.example.calltimerhook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers

class Hook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName == "com.android.phone") {
            try {
                val cls = XposedHelpers.findClass("com.android.internal.telephony.GsmCdmaCallTracker", lpparam.classLoader)
                // Замена таймеров
                XposedHelpers.setStaticIntField(cls, "T305_TIMER", 1000) // 1 сек
                XposedHelpers.setStaticIntField(cls, "T308_TIMER", 1200) // 1.2 сек
            } catch (e: Throwable) {
                XposedHelpers.log("CallTimerHook error: " + e.message)
            }
        }
    }
}
